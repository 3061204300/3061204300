"""HACS Frontend"""
from .version import VERSION

def locate_dir():
    return __path__[0]